# RustHacks
Easy to setup rust hack bundle 
